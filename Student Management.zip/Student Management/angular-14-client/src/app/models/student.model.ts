export class Student {
  id?: any;
  name?: string;
  mobile?:number;
  email?:string;
  description?: string;
  published?: boolean;
}

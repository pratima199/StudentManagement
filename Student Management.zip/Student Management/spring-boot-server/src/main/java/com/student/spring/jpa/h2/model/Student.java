package com.student.spring.jpa.h2.model;

import javax.persistence.*;

@Entity
@Table(name = "students")
public class Student {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;

	@Column(name = "name")
	private String name;

	@Column(name = "mobile")
	private Long mobile;

	@Column(name = "email")
	private String email;

	@Column(name = "description")
	private String description;

	@Column(name = "published")
	private boolean published;

	public Student() {

	}

	public Student(String name, Long mobile, String email, String description, boolean published) {
		this.name = name;
		this.mobile = mobile;
		this.email = email;
		this.description = description;
		this.published = published;
	}

	public long getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getMobile() {
		return mobile;
	}

	public void setMobile(Long mobile) {
		this.mobile = mobile;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public boolean isPublished() {
		return published;
	}

	public void setPublished(boolean isPublished) {
		this.published = isPublished;
	}

	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + ", mobile=" + mobile + ", email=" + email + ", desc=" + description + ", published=" + published + "]";
	}

}

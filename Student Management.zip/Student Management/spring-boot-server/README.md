## Technology
Springboot, JPA, H2-DB(InMemory), Angular-14 

##Step to run
 
## Angular Application
 ng serve --port 8081
## Spring Boot application
mvn spring-boot:run




